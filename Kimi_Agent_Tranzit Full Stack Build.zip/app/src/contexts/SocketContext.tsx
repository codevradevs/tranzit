import { createContext, useContext, useEffect, useRef, useState, type ReactNode } from 'react';
import { io, type Socket } from 'socket.io-client';
import { useAuth } from './AuthContext';

interface SocketContextType {
  socket: Socket | null;
  isConnected: boolean;
  joinRoom: (userId: string, role: string) => void;
  updateLocation: (shipmentId: string, location: any) => void;
  updateShipmentStatus: (shipmentId: string, status: string, note?: string) => void;
}

const SocketContext = createContext<SocketContextType | undefined>(undefined);

export function SocketProvider({ children }: { children: ReactNode }) {
  const socketRef = useRef<Socket | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const { user } = useAuth();

  useEffect(() => {
    // Initialize socket connection
    const socket = io(window.location.origin);
    socketRef.current = socket;

    socket.on('connect', () => {
      console.log('Socket connected:', socket.id);
      setIsConnected(true);
      
      // Join user room if authenticated
      if (user) {
        socket.emit('join', { userId: user.id, role: user.role });
      }
    });

    socket.on('disconnect', () => {
      console.log('Socket disconnected');
      setIsConnected(false);
    });

    socket.on('connect_error', (error) => {
      console.error('Socket connection error:', error);
      setIsConnected(false);
    });

    return () => {
      socket.disconnect();
    };
  }, []);

  // Re-join room when user changes
  useEffect(() => {
    if (socketRef.current && isConnected && user) {
      socketRef.current.emit('join', { userId: user.id, role: user.role });
    }
  }, [user, isConnected]);

  const joinRoom = (userId: string, role: string) => {
    if (socketRef.current) {
      socketRef.current.emit('join', { userId, role });
    }
  };

  const updateLocation = (shipmentId: string, location: any) => {
    if (socketRef.current && user) {
      socketRef.current.emit('location:update', {
        shipmentId,
        location,
        driverId: user.id
      });
    }
  };

  const updateShipmentStatus = (shipmentId: string, status: string, note?: string) => {
    if (socketRef.current) {
      socketRef.current.emit('shipment:status', {
        shipmentId,
        status,
        note
      });
    }
  };

  return (
    <SocketContext.Provider
      value={{
        socket: socketRef.current,
        isConnected,
        joinRoom,
        updateLocation,
        updateShipmentStatus
      }}
    >
      {children}
    </SocketContext.Provider>
  );
}

export function useSocket() {
  const context = useContext(SocketContext);
  if (context === undefined) {
    throw new Error('useSocket must be used within a SocketProvider');
  }
  return context;
}
